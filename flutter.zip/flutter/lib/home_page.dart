import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart'; // Firebase çıkışı için
import 'ble_service.dart';
import 'login_page.dart'; // Çıkış yapınca dönülecek sayfa

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late BleService ble;

  // Değişkenler
  int yurume = 0;
  int kosma = 0;
  int ziplama = 0;
  int yumruk = 0;

  String durum = "BLE Bağlanıyor...";
  Color renk = Colors.orange;

  @override
  void initState() {
    super.initState();
    // Servisi başlat
    ble = BleService();
    ble.start();

    // Verileri dinle
    ble.stream.listen((data) {
      if (!mounted) return;
      setState(() {
        yurume = data[0];
        kosma = data[1];
        ziplama = data[2];
        yumruk = data[3];
        durum = "Cihaz Bağlı ✅";
        renk = Colors.green;
      });
    });
  }

  // --- ÇIKIŞ YAP FONKSİYONU ---
  void cikisYap() async {
    // 1. BLE bağlantısını güvenli şekilde kapat
    ble.dispose();

    // 2. Firebase oturumunu kapat
    await FirebaseAuth.instance.signOut();

    // 3. Giriş sayfasına geri dön (Geri tuşuna basınca tekrar Home'a gelmesin diye Replacement kullanıyoruz)
    if (mounted) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const LoginPage()),
      );
    }
  }

  @override
  void dispose() {
    ble.dispose(); // Sayfa kapanırsa bağlantıyı kes
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Akıllı Bileklik"),
        backgroundColor: Colors.blueGrey, // Biraz renk kattım :)
        foregroundColor: Colors.white,
        
        // --- SAĞ ÜSTTEKİ ÇIKIŞ BUTONU ---
        actions: [
          IconButton(
            onPressed: cikisYap,
            icon: const Icon(Icons.logout),
            tooltip: "Çıkış Yap",
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Durum Kutusu
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: renk.withOpacity(0.2),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: renk, width: 2),
              ),
              child: Text(
                durum,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: renk,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(height: 20),
            
            // Kartlar
            Expanded(
              child: ListView(
                children: [
                  _kart("Yürüme", yurume, Icons.directions_walk, Colors.blue),
                  _kart("Koşma", kosma, Icons.directions_run, Colors.orange),
                  _kart("Zıplama", ziplama, Icons.trending_up, Colors.green),
                  _kart("Yumruk", yumruk, Icons.sports_mma, Colors.red),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Kart Tasarımı (Biraz renklendirdim)
  Widget _kart(String baslik, int deger, IconData icon, Color iconRengi) {
    return Card(
      elevation: 4,
      margin: const EdgeInsets.symmetric(vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        leading: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: iconRengi.withOpacity(0.1),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, size: 30, color: iconRengi),
        ),
        title: Text(
          baslik,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
        ),
        trailing: Text(
          deger.toString(),
          style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}