import 'dart:async';
import 'dart:convert';
import 'dart:io'; // Platform kontrolü için
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:permission_handler/permission_handler.dart'; // İzinler için

class BleService {
  // v2.x sürümünde Guid nesnesi doğrudan kullanılır
  final Guid serviceUUID = Guid("12345678-1234-1234-1234-1234567890ab");
  final Guid charUUID = Guid("abcdefab-1234-5678-1234-abcdefabcdef");

  BluetoothDevice? _device;
  StreamSubscription? _scanSubscription;
  
  // Verileri Home sayfasına aktaracak yayın aracı
  final StreamController<List<int>> _controller = StreamController.broadcast();
  Stream<List<int>> get stream => _controller.stream;

  /// BAŞLAT
  Future<void> start() async {
    // 1. Önce İzinleri İste (Android için Kritik)
    await _izinleriIste();

    // 2. Bluetooth açık mı kontrol et
    // v2.x'te adapterState bir Stream'dir.
    if (FlutterBluePlus.adapterStateNow != BluetoothAdapterState.on) {
      try {
         // Android'de Bluetooth'u açmayı teklif edebiliriz
         if (Platform.isAndroid) {
           await FlutterBluePlus.turnOn();
         } else {
           // iOS veya desteklenmeyen durumlar için bekle
           await FlutterBluePlus.adapterState
            .where((s) => s == BluetoothAdapterState.on)
            .first;
         }
      } catch (e) {
        print("Bluetooth açma hatası: $e");
      }
    }

    // 3. Taramayı Başlat
    // withServices parametresi sayesinde sadece bizim cihazı arar, pil tasarrufu sağlar.
    await FlutterBluePlus.startScan(
      withServices: [serviceUUID], 
      timeout: const Duration(seconds: 10)
    );

    // 4. Sonuçları Dinle
    _scanSubscription = FlutterBluePlus.scanResults.listen((results) async {
      for (final r in results) {
        // Zaten withServices ile filtreledik ama yine de kontrol edelim
        if (r.advertisementData.serviceUuids.contains(serviceUUID)) {
          
          await FlutterBluePlus.stopScan(); // Taramayı durdur
          _scanSubscription?.cancel();      // Dinlemeyi bırak
          
          await _connect(r.device);         // Bağlan
          break; // Döngüden çık
        }
      }
    });
  }

  /// İZİN İSTEME FONKSİYONU
  Future<void> _izinleriIste() async {
    // Android S (12) ve üzeri için gerekli izinler
    if (Platform.isAndroid) {
      Map<Permission, PermissionStatus> statuses = await [
        Permission.bluetoothScan,
        Permission.bluetoothConnect,
        Permission.location, // Bazı durumlarda yine de gerekebilir
      ].request();
      
      print("İzin durumları: $statuses");
    }
  }

  /// BAĞLAN
  Future<void> _connect(BluetoothDevice device) async {
    _device = device;
    try {
      // Bağlan
      await device.connect(); // autoConnect parametresi v2'de değişti, varsayılan kalsın

      // Android MTU Ayarı
      if (Platform.isAndroid) {
        await device.requestMtu(512);
      }

      // Servisleri Keşfet
      final services = await device.discoverServices();

      for (final s in services) {
        if (s.uuid == serviceUUID) { // Guid karşılaştırması
          for (final c in s.characteristics) {
            if (c.uuid == charUUID) {
              
              // Bildirimleri aç
              await c.setNotifyValue(true);

              // Veri geldiğinde oku
              // v2.x'te 'lastValueStream' kullanılır
              c.lastValueStream.listen((value) {
                _onData(value);
              });
            }
          }
        }
      }
    } catch (e) {
      print("Bağlantı hatası: $e");
    }
  }

  /// VERİ İŞLEME
  void _onData(List<int> value) {
    if (value.isEmpty) return;

    try {
      // Byte -> String ("10,0,5,2")
      final text = utf8.decode(value);
      
      // String -> Liste
      final parts = text.split(',');

      if (parts.length == 4) {
        final data = [
          int.tryParse(parts[0]) ?? 0,
          int.tryParse(parts[1]) ?? 0,
          int.tryParse(parts[2]) ?? 0,
          int.tryParse(parts[3]) ?? 0,
        ];
        _controller.add(data);
      }
    } catch (e) {
      print("Veri işleme hatası: $e");
    }
  }

  void dispose() {
    _scanSubscription?.cancel();
    _device?.disconnect();
    _controller.close();
  }
}