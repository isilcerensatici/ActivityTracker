import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'home_page.dart'; // Sayfa geçişi için bunu ekledik!

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  
  String errorMessage = "";
  bool isLoading = false; // Yükleniyor animasyonu için

  final String _fakeDomain = "@bileklik.com";

  // --- GİRİŞ YAP ---
  Future<void> signIn() async {
    if (_usernameController.text.isEmpty || _passwordController.text.isEmpty) {
      setState(() => errorMessage = "Lütfen boş alan bırakmayın.");
      return;
    }

    setState(() => isLoading = true); // Yükleniyor başlat

    try {
      String finalEmail = _usernameController.text.trim() + _fakeDomain;
      
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: finalEmail,
        password: _passwordController.text.trim(),
      );

      // Başarılı olursa Ana Sayfaya git
      if (mounted) {
        Navigator.pushReplacement(
          context, 
          MaterialPageRoute(builder: (context) => const HomePage())
        );
      }

    } on FirebaseAuthException catch (e) {
      setState(() {
        if (e.code == 'user-not-found' || e.code == 'invalid-credential') {
          errorMessage = "Kullanıcı bulunamadı veya şifre yanlış.";
        } else if (e.code == 'wrong-password') {
          errorMessage = "Şifre yanlış.";
        } else {
          errorMessage = "Giriş hatası: ${e.message}";
        }
      });
    } finally {
      if (mounted) setState(() => isLoading = false); // Yükleniyor durdur
    }
  }

  // --- KAYIT OL ---
  Future<void> register() async {
    if (_usernameController.text.isEmpty || _passwordController.text.isEmpty) {
      setState(() => errorMessage = "Lütfen boş alan bırakmayın.");
      return;
    }

    setState(() => isLoading = true);

    try {
      String finalEmail = _usernameController.text.trim() + _fakeDomain;

      await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: finalEmail,
        password: _passwordController.text.trim(),
      );

      // Kayıt başarılı olunca da direkt Ana Sayfaya alalım
      if (mounted) {
        Navigator.pushReplacement(
          context, 
          MaterialPageRoute(builder: (context) => const HomePage())
        );
      }
      
    } on FirebaseAuthException catch (e) {
      setState(() {
        if (e.code == 'weak-password') {
          errorMessage = "Şifre çok zayıf (en az 6 karakter olmalı).";
        } else if (e.code == 'email-already-in-use') {
          errorMessage = "Bu kullanıcı adı zaten alınmış.";
        } else {
          errorMessage = "Kayıt hatası: ${e.message}";
        }
      });
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Giriş Yap")),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.watch, size: 80, color: Colors.grey),
              const SizedBox(height: 20),
              
              TextField(
                controller: _usernameController,
                decoration: const InputDecoration(
                  labelText: "Kullanıcı Adı",
                  hintText: "Örn: ahmet123",
                  prefixIcon: Icon(Icons.person),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 16),
              
              TextField(
                controller: _passwordController,
                decoration: const InputDecoration(
                  labelText: "Şifre",
                  prefixIcon: Icon(Icons.lock),
                  border: OutlineInputBorder(),
                ),
                obscureText: true,
              ),
              
              const SizedBox(height: 10),
              
              // Hata veya Yükleniyor göstergesi
              if (isLoading)
                const CircularProgressIndicator()
              else
                Text(
                  errorMessage,
                  style: const TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
                  textAlign: TextAlign.center,
                ),
              
              const SizedBox(height: 20),
              
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      onPressed: signIn,
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 15),
                        backgroundColor: Colors.blueGrey,
                        foregroundColor: Colors.white
                      ),
                      child: const Text("Giriş Yap"),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: register,
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 15),
                        backgroundColor: Colors.green,
                        foregroundColor: Colors.white
                      ),
                      child: const Text("Kayıt Ol"),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}