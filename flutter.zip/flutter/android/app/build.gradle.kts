plugins {
    id("com.android.application")
    id("kotlin-android")
    // Flutter Plugin
    id("dev.flutter.flutter-gradle-plugin")
    // FIREBASE EKLENTISI (Bunu ekledim)
    id("com.google.gms.google-services")
}

android {
    namespace = "com.example.akilli_bileklik"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_17.toString()
    }

   defaultConfig {
        // İŞTE APPLICATION ID BURADA:
        applicationId = "com.example.akilli_bileklik"
        
        // DEĞİŞTİRDİĞİMİZ KISIM BURASI:
        // flutter.minSdkVersion yerine doğrudan 21 yazıyoruz.
        minSdk = flutter.minSdkVersion 
        
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("debug")
        }
    }
}

flutter {
    source = "../.."
}
