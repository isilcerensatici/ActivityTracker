package com.example.akilli_bileklik

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
